const Biography = (props) => {
  
    return (
        <div>
          <h3 className={props.className}><span>Rosaire</span> <span>Kota</span></h3>
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Autem culpa quibusdam totam eum aut molestiae atque quod labore sequi, eveniet, laboriosam expedita temporibus! Voluptatibus iste at nostrum, repudiandae aut atque.</p>
        </div>
    )
}
export default Biography;