const Bouton = (props) => {
    return (
        <button className={props.className}>X</button>
    )
}
export default Bouton;