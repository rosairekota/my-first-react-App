// on importe ReacDOM pour bracher nos composant

import ReacDOM from "react-dom";


import App from "./app";

ReacDOM.render(<App />, document.querySelector("#app"));
